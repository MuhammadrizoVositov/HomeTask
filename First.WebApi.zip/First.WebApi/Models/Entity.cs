﻿namespace First.WebApi.Models;

public class Entity : IEntity
{
    public Guid Id { get ; set ; }
}
