﻿using FileBaseContext.Abstractions.Models.Entity;

namespace First.WebApi.Models;

public interface IEntity:IFileSetEntity<Guid>
{

}
